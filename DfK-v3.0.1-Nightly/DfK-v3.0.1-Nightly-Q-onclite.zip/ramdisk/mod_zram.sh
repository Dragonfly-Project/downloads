#!/system/bin/sh
# DRAGONFLY KERNEL

zram_percent=85

# Set ZRam
swapoff /dev/block/zram0

set -- `cat /proc/meminfo`
TOTAL=$(( ${2} * 1024 ))
size=$(( TOTAL * zram_percent / 100 ))
echo 1 >/sys/block/zram0/reset

if (( size )); then
	echo 6 >/sys/block/zram0/max_compression_streams
	echo $size >/sys/block/zram0/disksize
	mkswap /dev/block/zram0
	swapon /dev/block/zram0
fi

