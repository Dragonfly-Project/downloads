# Remove user's DfT app
dir=`ls -d /data/app/com.igoryan94.dft*`
[ -d "$dir" ] && rm -rf $dir
true
