#!/system/bin/sh

remount_iops() {
	for b in `/system/bin/mount | cut -d ' ' -f3`; do
		case $b in
			/sys*)
				continue
				;;
			*)
				nice -n 19 mount -o remount,nobarrier,noatime,data=writeback,noblock_validity $b
				;;
		esac
	done
}

# Optimize FSs
remount_iops

# Fix TTL to 64 if kernel does support that
iptables -t mangle -A POSTROUTING -o rmnet+ -j TTL --ttl-set 64

# Early dftd start
/system/bin/dftd &

# Repeat FSs optimizations for fresh (re)mounts
(
	sleep 20
	remount_iops
) &
