#!/system/bin/sh
# Copyright:
#		2020, Igor Kozlovskiy (igoryan94@gmail.com)
#									 (@DfP_DEV @ Telegram)

profiles_check_rate=3

sysdir=/data/adb/modules/dftweaks
dir=/dev/dftd

write() {
	echo -n $2 >$1
}

contains() {
	what=$2
	where=$1
	ret=1
	case $where in *$what*)ret=0;; *)ret=1;; esac
	echo $ret
}

r_param() {
	name="$dir/$1"
	def=$2
	[ ! -d $dir ] && mkdir -p $dir && chmod -R 777 $dir
	( [ ! -f $name ] || [ -z "$(cat $name)" ] ) && echo "$def" >$name
	(( cur == -1000 )) && echo "$def" >$name
	chmod -R 777 $name
	echo $(cat $name)
}

r_param_mm() {
	name="$dir/$1"
	def=$2
	min=$3
	max=$4
	[ ! -d $dir ] && mkdir -p $dir && chmod -R 777 $dir
	( [ ! -f $name ] || [ -z "$(cat $name)" ] ) && echo "$def" >$name
	cur=$(cat $name)
	(( cur == -1000 )) && cur=$def && echo "$def" >$name
	(( cur < min )) && cur=$min && echo "$min" >$name
	(( cur > max )) && cur=$max && echo "$max" >$name
	chmod -R 777 $name
	echo $cur
}

wr_param() {
	name="$dir/$1"
	val=$2
	[ ! -d $dir ] && mkdir -p $dir && chmod -R 777 $dir
	chmod -R 777 $name
	echo "$val" >$name
}

wr_param_add() {
	name="$dir/$1"
	val=$2
	[ ! -d $dir ] && mkdir -p $dir && chmod -R 777 $dir
	chmod -R 777 $name
	echo "$val" >>$name
}

rm_param() {
	if [ "$1" = "all" ]; then
		rm "$dir"/* &>/dev/null
		rm "$dir"/.* &>/dev/null
		return
	fi
	name="$dir/$1"
	[ ! -d $dir ] && mkdir -p $dir && chmod -R 777 $dir
	[ -f $name ] && rm -f $name
}

zram() {
	percent=93
	TOTAL_RAM=$(awk '/^MemTotal:/{print $2}' /proc/meminfo) 2>/dev/null
	disksz_mb=$(( TOTAL_RAM * percent/102400 ))
	disksz=$((${disksz_mb}*1024*1024))
	swapoff /dev/block/zram0 &>/dev/null
	write /sys/block/zram0/reset 1
	write /sys/block/zram0/comp_algorithm lzo
	write /sys/block/zram0/max_comp_streams 8
	write /sys/block/zram0/reset 1
	write /sys/block/zram0/disksize ${disksz_mb}M
	mkswap /dev/block/zram0 &>/dev/null
	swapon /dev/block/zram0 &>/dev/null
	setprop ro.config.zram true
	setprop ro.config.zram.support true
	write /proc/sys/vm/swappiness 100
}

# Others #
is_charging() {
	txt=`cat /sys/class/power_supply/battery/status`
	[ "$txt" = "Charging" ]
	return $?
}
#
is_batt_ok() {
	thr=${1:-75}
	cap=`cat /sys/class/power_supply/battery/capacity`
	if (( cap >= thr )); then
		return 0
	else
		return 1
	fi
}
#
battw() {
	while :; do
		if (is_batt_ok ${1:-75} || is_charging); then
			break
		else
			sleep 15
		fi
	done
}
##
alias load='l=`cat /proc/loadavg | cut -d " " -f1`; echo ${l/./}'
loadw() {
	thr=${1:-650}
	while :; do
		load=`load`
		(( load < thr )) && break
		sleep 4
	done
}
#
list_header="${dir}/_list_"
list_bak_header="${dir}/../.list_"
list_reset() { echo >${list_header}${1:-main}; }
list_add() { echo "$2" >>${list_header}${1:-main}; }
list_backup() { cp ${list_header}${1:-main} ${list_bak_header}${1:-main}; }
list_restore() { mv ${list_bak_header}${1:-main} ${list_header}${1:-main}; }
##########

## DfT profiles init
setprop persist.dft.profile 2

# Prepare settings
setprop persist.dft.thermal 1
#thermal stop

# Start main daemon
/system/bin/dftd &
while :; do
	renice 10 0 || renice -n 10 0
	pids=`pidof dftd`
	n=0
	for x in $pids; do
		(( n++ ))
	done
	if (( n > 7 )); then
		killall -9 dftd
		unset pids
	fi
	if [ -z "$pids" ]; then
		/system/bin/dftd &
		echo -n "`date`" | tee -a $sysdir/daemon_control.log
		echo "DfT daemon relaunched!!!" | tee /dev/kmsg \
				| tee -a $sysdir/daemon_control.log
	fi

	sleep 20
done &

while :; do
	if [ -f $dir/.restart_dftd ]; then
		killall -9 dftd
		/system/bin/dftd &
		sleep 2
		pidof dftd && rm $dir/.restart_dftd
	fi
	sleep 4
done &

# Start resources control daemon
#while :; do
#	pids=`pgrep -f rcond`
#
#	if [ -z "$pids" ]; then
#		/system/bin/rcond &
#		echo -n "`date`" | tee -a $sysdir/daemon_control.log
#		echo "Resource control daemon relaunched!!!" | tee /dev/kmsg \
#				| tee -a $sysdir/daemon_control.log
#	fi
#
#	sleep 120
#done &

(
sleep 10


# Initial setup
SUPP_HELIX_SCHEDUTIL=false
grep -q helix_schedutil /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors && \
		SUPP_HELIX_SCHEDUTIL=true
SUPP_GPU_BOOST=false
[ -f /sys/devices/platform/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/adrenoboost ] && \
		SUPP_GPU_BOOST=true



iptables -t mangle -A POSTROUTING -o rmnet+ -j TTL --ttl-set 64

# Update reset all params
upd_val=`set -- \`cat /proc/version\`; echo $3`
if [ "`r_param .updated 0`" != "$upd_val" ]; then
	# prepare
	list_backup hung_tasks_stats

	## reset...
	rm_param all

	# restore
	list_restore hung_tasks_stats

	# save update value
	wr_param .updated "$upd_val"
fi

# Re-initialize ZRam
zram

sleep 10


sleep 10

# Force disable SELinux enforcing
setenforce 0

# DfT profiles
setprop persist.dft.profile.reapply 0
last_prof=
i=0
while :; do
	(( i++ ))
	prof=`getprop persist.dft.profile`
	( (( ! i )) && [ -f "$dir"/.enable_smart_scaling ] ) && prof=0
	if [ "`getprop persist.dft.profile.reapply`" = 1 ]; then
		i=0
		last_prof=
		setprop persist.dft.profile.reapply 0
	fi
	wr_param cur_profile $prof
	if [ "$prof" != "$last_prof" ]; then
		wr_param last_profile $prof
		# var
		little=/sys/devices/system/cpu/cpufreq/policy0/
		big=/sys/devices/system/cpu/cpufreq/policy4/
		#
		rmdir /dev/cpuset/top-app/boost
		case $prof in
		# Dynamic scaling
		0)
		;;
		# Shifted Balance
		1)
			# CPUfreq: little cluster
			chmod 644 $little/scaling_min_freq
			echo 614400 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $little/scaling_max_freq
			echo 1036800 >$little/scaling_max_freq
			chmod 444 $little/scaling_max_freq
			echo conservative >$little/scaling_governor
			chmod 644 $little/conservative/*
			# CPUfreq: big cluster
			chmod 644 $little/scaling_min_freq
			echo 633600 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $big/scaling_max_freq
			echo 1401600 >$big/scaling_max_freq
			chmod 444 $big/scaling_max_freq
			if $SUPP_HELIX_SCHEDUTIL; then
				echo helix_schedutil >$big/scaling_governor
				chmod 644 $big/helix_schedutil/*
				echo 3 >$big/helix_schedutil/bit_shift1
				echo 4 >$big/helix_schedutil/bit_shift2
				echo 30 >$big/helix_schedutil/target_load1
				echo 75 >$big/helix_schedutil/target_load2
			else
				echo schedutil >$big/scaling_governor
				chmod 644 $big/schedutil/*
				echo 0 >$big/schedutil/up_rate_limit_us
				echo 0 >$big/schedutil/down_rate_limit_us
				echo 1363200 >$big/schedutil/hispeed_freq
				echo 85 >$big/schedutil/hispeed_load
				echo 0 >$big/schedutil/pl
			fi
			# GPU boost
			$SUPP_GPU_BOOST && \
					echo 0 >/sys/devices/platform/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/adrenoboost
			# GPU frequency
			echo 560 >/sys/class/kgsl/kgsl-3d0/max_clock_mhz
		;;
		# Balance (default)
		2)
			# CPUfreq: little cluster
			chmod 644 $little/scaling_min_freq
			echo 614400 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $little/scaling_max_freq
			echo 1804800 >$little/scaling_max_freq
			chmod 444 $little/scaling_max_freq
			if $SUPP_HELIX_SCHEDUTIL; then
				echo helix_schedutil >$little/scaling_governor
				chmod 644 $little/helix_schedutil/*
				echo 5 >$little/helix_schedutil/bit_shift1
				echo 3 >$little/helix_schedutil/bit_shift2
				echo 30 >$little/helix_schedutil/target_load1
				echo 65 >$little/helix_schedutil/target_load2
			else
				echo schedutil >$little/scaling_governor
				chmod 644 $little/schedutil/*
				echo 0 >$little/schedutil/up_rate_limit_us
				echo 0 >$little/schedutil/down_rate_limit_us
				echo 1363200 >$little/schedutil/hispeed_freq
				echo 85 >$little/schedutil/hispeed_load
				echo 0 >$little/schedutil/pl
			fi
			# CPUfreq: big cluster
			chmod 644 $little/scaling_min_freq
			echo 633600 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $big/scaling_max_freq
			echo 1804800 >$big/scaling_max_freq
			chmod 444 $big/scaling_max_freq
			if $SUPP_HELIX_SCHEDUTIL; then
				echo helix_schedutil >$big/scaling_governor
				chmod 644 $big/helix_schedutil/*
				echo 1 >$big/helix_schedutil/bit_shift1
				echo 5 >$big/helix_schedutil/bit_shift2
				echo 27 >$big/helix_schedutil/target_load1
				echo 72 >$big/helix_schedutil/target_load2
			else
				echo schedutil >$big/scaling_governor
				chmod 644 $big/schedutil/*
				echo 0 >$big/schedutil/up_rate_limit_us
				echo 0 >$big/schedutil/down_rate_limit_us
				echo 1401600 >$big/schedutil/hispeed_freq
				echo 85 >$big/schedutil/hispeed_load
				echo 0 >$big/schedutil/pl
			fi
			# GPU boost
			$SUPP_GPU_BOOST && \
					echo 1 >/sys/devices/platform/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/adrenoboost
			# GPU frequency
			echo 725 >/sys/class/kgsl/kgsl-3d0/max_clock_mhz
		;;
		# Performance
		3)
			# CPUfreq: little cluster
			chmod 644 $little/scaling_min_freq
			echo 614400 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $little/scaling_max_freq
			echo 2016000 >$little/scaling_max_freq
			chmod 444 $little/scaling_max_freq
			if $SUPP_HELIX_SCHEDUTIL; then
				echo helix_schedutil >$little/scaling_governor
				chmod 644 $little/helix_schedutil/*
				echo 1 >$little/helix_schedutil/bit_shift1
				echo 7 >$little/helix_schedutil/bit_shift2
				echo 33 >$little/helix_schedutil/target_load1
				echo 67 >$little/helix_schedutil/target_load2
			else
				echo schedutil >$little/scaling_governor
				chmod 644 $little/schedutil/*
				echo 4000 >$little/schedutil/up_rate_limit_us
				echo 10000 >$little/schedutil/down_rate_limit_us
				echo 20000 >$little/schedutil/rate_limit_us
				echo 1536000 >$little/schedutil/hispeed_freq
				echo 87 >$little/schedutil/hispeed_load
				echo 0 >$little/schedutil/pl
			fi
			# CPUfreq: big cluster
			chmod 644 $little/scaling_min_freq
			echo 1094400 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $big/scaling_max_freq
			echo 2016000 >$big/scaling_max_freq
			chmod 444 $big/scaling_max_freq
			if $SUPP_HELIX_SCHEDUTIL; then
				echo helix_schedutil >$big/scaling_governor
				chmod 644 $big/helix_schedutil/*
				echo 1 >$big/helix_schedutil/bit_shift1
				echo 7 >$big/helix_schedutil/bit_shift2
				echo 33 >$big/helix_schedutil/target_load1
				echo 67 >$big/helix_schedutil/target_load2
			else
				echo schedutil >$big/scaling_governor
				chmod 644 $big/schedutil/*
				echo 0 >$big/schedutil/up_rate_limit_us
				echo 30000 >$big/schedutil/down_rate_limit_us
				echo 10000 >$big/schedutil/rate_limit_us
				echo 1804800 >$big/schedutil/hispeed_freq
				echo 82 >$big/schedutil/hispeed_load
				echo 0 >$big/schedutil/pl
			fi
			# GPU boost
			$SUPP_GPU_BOOST && \
					echo 1 >/sys/devices/platform/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/adrenoboost
			# GPU frequency
			echo 825 >/sys/class/kgsl/kgsl-3d0/max_clock_mhz
		;;
		# Gaming
		4)
			# CPUfreq: little cluster
			chmod 644 $little/scaling_min_freq
			echo 883200 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $little/scaling_max_freq
			echo 1804800 >$little/scaling_max_freq
			chmod 444 $little/scaling_max_freq
			if $SUPP_HELIX_SCHEDUTIL; then
				echo helix_schedutil >$little/scaling_governor
				chmod 644 $little/helix_schedutil/*
				echo 4 >$little/helix_schedutil/bit_shift1
				echo 10 >$little/helix_schedutil/bit_shift2
				echo 65 >$little/helix_schedutil/target_load1
				echo 67 >$little/helix_schedutil/target_load2
			else
				echo schedutil >$little/scaling_governor
				chmod 644 $little/schedutil/*
				echo 0 >$little/schedutil/up_rate_limit_us
				echo 0 >$little/schedutil/down_rate_limit_us
				echo 1363200 >$little/schedutil/hispeed_freq
				echo 85 >$little/schedutil/hispeed_load
				echo 0 >$little/schedutil/pl
			fi
			# CPUfreq: big cluster
			chmod 644 $little/scaling_min_freq
			echo 1094400 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $big/scaling_max_freq
			echo 2016000 >$big/scaling_max_freq
			chmod 444 $big/scaling_max_freq
			if $SUPP_HELIX_SCHEDUTIL; then
				echo helix_schedutil >$big/scaling_governor
				chmod 644 $big/helix_schedutil/*
				echo 3 >$big/helix_schedutil/bit_shift1
				echo 10 >$big/helix_schedutil/bit_shift2
				echo 25 >$big/helix_schedutil/target_load1
				echo 75 >$big/helix_schedutil/target_load2
			else
				echo schedutil >$big/scaling_governor
				chmod 644 $big/schedutil/*
				echo 0 >$big/schedutil/up_rate_limit_us
				echo 0 >$big/schedutil/down_rate_limit_us
				echo 1401600 >$big/schedutil/hispeed_freq
				echo 85 >$big/schedutil/hispeed_load
				echo 0 >$big/schedutil/pl
			fi
			# GPU boost
			$SUPP_GPU_BOOST && \
					echo 2 >/sys/devices/platform/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/adrenoboost
			# GPU frequency
			echo 825 >/sys/class/kgsl/kgsl-3d0/max_clock_mhz
		;;
		# Maximal gaming
		5)
			# CPUfreq: little cluster
			chmod 644 $little/scaling_min_freq
			echo 1804800 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $little/scaling_max_freq
			echo 2016000 >$little/scaling_max_freq
			if $SUPP_HELIX_SCHEDUTIL; then
				chmod 444 $little/scaling_max_freq
				echo helix_schedutil >$little/scaling_governor
				chmod 644 $little/helix_schedutil/*
				echo 1 >$little/helix_schedutil/bit_shift1
				echo 10 >$little/helix_schedutil/bit_shift2
				echo 25 >$little/helix_schedutil/target_load1
				echo 75 >$little/helix_schedutil/target_load2
			else
				echo schedutil >$little/scaling_governor
				chmod 644 $little/schedutil/*
				echo 0 >$little/schedutil/up_rate_limit_us
				echo 0 >$little/schedutil/down_rate_limit_us
				echo 1401600 >$little/schedutil/hispeed_freq
				echo 85 >$little/schedutil/hispeed_load
				echo 0 >$little/schedutil/pl
			fi
			# CPUfreq: big cluster
			chmod 644 $little/scaling_min_freq
			echo 1804800 >$little/scaling_min_freq
			chmod 444 $little/scaling_min_freq
			chmod 644 $big/scaling_max_freq
			echo 2016000 >$big/scaling_max_freq
			chmod 444 $big/scaling_max_freq
			if $SUPP_HELIX_SCHEDUTIL; then
				echo helix_schedutil >$big/scaling_governor
				chmod 644 $big/helix_schedutil/*
				echo 1 >$big/helix_schedutil/bit_shift1
				echo 10 >$big/helix_schedutil/bit_shift2
				echo 25 >$big/helix_schedutil/target_load1
				echo 75 >$big/helix_schedutil/target_load2
			else
				echo schedutil >$big/scaling_governor
				chmod 644 $big/schedutil/*
				echo 0 >$big/schedutil/up_rate_limit_us
				echo 0 >$big/schedutil/down_rate_limit_us
				echo 1401600 >$big/schedutil/hispeed_freq
				echo 85 >$big/schedutil/hispeed_load
				echo 0 >$big/schedutil/pl
			fi
			# GPU boost
			$SUPP_GPU_BOOST && \
					echo 3 >/sys/devices/platform/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/adrenoboost
			# GPU frequency
			echo 825 >/sys/class/kgsl/kgsl-3d0/max_clock_mhz
		;;
		*)setprop persist.dft.profile 2
		;; esac
		last_prof=$prof
	fi

	sleep $profiles_check_rate
done &

# Collect hung processes load statistics
alias cmd='toybox top -bn2 | head -n6 | tail -n 1'
while :; do
	break
	(( ! `r_param_mm stats.enabled 1 0 1` )) && sleep 180 && continue

	out=`cmd`
	case $out in *top*);; *)
		#list_add hung_tasks_stats "`date`: $out"
		wr_param_add _hung_tasks_stats "`date`: $out"
	;; esac

	# set -- wc -l $dir/_hung_tasks_stats
	# lines=$1
	# (( lines > 15 )) && \
	# 	cat $dir/_hung_tasks_stats | \
	# 		tail -n 15 $dir/_hung_tasks_stats > \
	# 			$dir/_hung_tasks_stats.tmp; \
	# 				mv $dir/_hung_tasks_stats.tmp \
	# 					$dir/_hung_tasks_stats

	sleep `r_param stats.timeout@15-300 45`
done &

sleep 10

# Tweaks
while :; do
	# Set LMK to better multitasking
	echo 0 >/sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
	echo 0 >/sys/module/lowmemorykiller/parameters/oom_reaper

	sleep 15
done &

# Start own thermal daemon
#/system/bin/tempd &

sleep 10

# Force disable SELinux enforcing
setenforce 0

##############

sleep 10

setprop persist.dft.profile.reapply 1

while sleep $((60 * 60 * 6)); do
	# TODO: needs busybox or some
	#		little fstrim utility to
	#		work, so now just sleep
	fstrim -v /data;
	fstrim -v /system;
	fstrim -v /cache;
	fstrim -v /vendor;
done &

iptables -t mangle -A POSTROUTING -o rmnet+ -j TTL --ttl-set 64

sleep 10

setprop persist.dft.profile.reapply 1

sleep 30

setprop persist.dft.profile.reapply 1

) &
