ui_print "  Tweaks installed successfully!"
