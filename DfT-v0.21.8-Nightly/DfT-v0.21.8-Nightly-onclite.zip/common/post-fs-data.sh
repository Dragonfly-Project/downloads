#!/system/bin/sh

#for b in `/system/bin/mount | cut -d ' ' -f3`; do
#	case $b in
#		/sys*)
#			continue
#			;;
#		*)
#			nice -n 19 mount -o remount,nobarrier,noatime,data=writeback,noblock_validity $b
#			;;
#	esac
#done

iptables -t mangle -A POSTROUTING -o rmnet+ -j TTL --ttl-set 64
